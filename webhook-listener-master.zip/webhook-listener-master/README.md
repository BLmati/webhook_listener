# mati-webhooks
a proof of concept to integrate webhooks with Node.js and Express.js
